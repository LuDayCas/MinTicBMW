
// let btns = document.querySelectorAll(".buttons");
// btns.forEach(li => {
//   li.addEventListener('click', function() {
//     btns.forEach(btn => btn.classList.remove('active'));
//       this.classList.add('active');
//   });
// });


